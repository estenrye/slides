#!/bin/bash
source /home/automation-user/.bashrc
pyenv exec $@
